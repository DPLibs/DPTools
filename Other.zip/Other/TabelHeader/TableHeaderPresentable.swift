//
//  TableHeaderPresentable.swift
//  dobro_2.0
//
//  Created by Дмитрий Поляков on 07.04.2020.
//  Copyright © 2020 Appcraft. All rights reserved.
//

import Foundation
import UIKit
import DPLibrary

protocol TableHeaderPresentable {
    var tableHeader: TableHeader { get }
    
    func addFromNibTo(table: UITableView)
    func didScroll(_ offset: CGFloat, table: UITableView?)
    func didScrollForSubviews(_ offset: CGFloat)
}

extension TableHeaderPresentable {
    
    func addFromNibTo(table: UITableView) {
        let headerView = self.tableHeader.headerView
        let headerHeight = self.tableHeader.headerHeight
        
        switch self.tableHeader.mode {
        case .tableHeaderView:
            let tableHeaderView = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: headerHeight))
            headerView.translatesAutoresizingMaskIntoConstraints = false
            tableHeaderView.addSubview(headerView)
            NSLayoutConstraint.activate([
                headerView.bottomAnchor.constraint(equalTo: tableHeaderView.bottomAnchor),
                headerView.leadingAnchor.constraint(equalTo: tableHeaderView.leadingAnchor),
                headerView.trailingAnchor.constraint(equalTo: tableHeaderView.trailingAnchor)
            ])
            table.tableHeaderView = tableHeaderView
            
        case let .backgroundView(headerColor, backgroundColor):
            let backgroundView = UIView()
            backgroundView.backgroundColor = backgroundColor
            headerView.translatesAutoresizingMaskIntoConstraints = false
            backgroundView.addSubview(headerView)
            NSLayoutConstraint.activate([
                headerView.topAnchor.constraint(equalTo: backgroundView.topAnchor),
                headerView.leadingAnchor.constraint(equalTo: backgroundView.leadingAnchor),
                headerView.trailingAnchor.constraint(equalTo: backgroundView.trailingAnchor)
            ])
            
            table.backgroundView = backgroundView
            table.contentInset.top = headerHeight - UIViewController.topOffsetScreen
            
            let tableHeaderView = UIView()
            table.tableHeaderView = tableHeaderView
            
            let topVw = UIView()
            topVw.backgroundColor = headerColor
            topVw.translatesAutoresizingMaskIntoConstraints = false
            backgroundView.addSubview(topVw)
            NSLayoutConstraint.activate([
                topVw.topAnchor.constraint(equalTo: headerView.bottomAnchor),
                topVw.leadingAnchor.constraint(equalTo: backgroundView.leadingAnchor),
                topVw.trailingAnchor.constraint(equalTo: backgroundView.trailingAnchor),
                topVw.bottomAnchor.constraint(equalTo: tableHeaderView.topAnchor)
            ])
            
            let tableFooterView = UIView()
            table.tableFooterView = tableFooterView
            
            let bottomVw = UIView()
            bottomVw.backgroundColor = backgroundColor
            bottomVw.translatesAutoresizingMaskIntoConstraints = false
            backgroundView.addSubview(bottomVw)
            NSLayoutConstraint.activate([
                bottomVw.topAnchor.constraint(equalTo: tableFooterView.bottomAnchor),
                bottomVw.leadingAnchor.constraint(equalTo: backgroundView.leadingAnchor),
                bottomVw.trailingAnchor.constraint(equalTo: backgroundView.trailingAnchor),
                bottomVw.bottomAnchor.constraint(equalTo: backgroundView.bottomAnchor)
            ])
        }
    }
    
    func didScroll(_ offset: CGFloat, table: UITableView? = nil) {
        switch self.tableHeader.mode {
        case .tableHeaderView:
            if offset <= 0 {
                for item in self.tableHeader.stretchConstraintList {
                    item.constraint.constant = item.currentValue - offset
                }
            }
        case .backgroundView:
            if offset <= -self.tableHeader.headerHeight {
                for item in self.tableHeader.stretchConstraintList {
                    item.constraint.constant = item.currentValue - offset - self.tableHeader.headerHeight
                }
            }
        }
        self.didScrollForSubviews(offset)
    }
    
    func didScrollForSubviews(_ offset: CGFloat) {}
    
}
