//
//  TableHeader.swift
//  dobro_2.0
//
//  Created by Дмитрий Поляков on 16.04.2020.
//  Copyright © 2020 Appcraft. All rights reserved.
//

import Foundation
import UIKit

struct TableHeader {
    
    var mode: Mode
    var headerView: UIView
    var headerHeight: CGFloat
    var stretchConstraintList: [StretchConstraint]
    
    enum Mode {
        case tableHeaderView
        case backgroundView(headerColor: UIColor, backgroundColor: UIColor)
    }
    
    struct StretchConstraint {
        var currentValue: CGFloat
        var constraint: NSLayoutConstraint
    }
    
}
