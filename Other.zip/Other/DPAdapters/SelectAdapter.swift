import Foundation
import UIKit

open class SelectTabView: UIView {
    
    private weak var scrollView: UIScrollView?
    
    public var items: [UIView] = [] {
        didSet {
            self.itemsDidSet()
        }
    }
    
    public init(items: [UIView]) {
        self.items = items
        super.init(frame: .zero)
        self.initCommon()
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        self.initCommon()
    }
    
    required public init?(coder: NSCoder) {
        super.init(coder: coder)
        self.initCommon()
    }
    
    private func initCommon() {
        self.prepareViews()
        self.itemsDidSet()
    }
    
    private func prepareViews() {
        
    }
    
    private func itemsDidSet() {
        
    }

}

class SelectAdapter {
    
    // MARK: - Public
    public var didSelectItems: (_ items: [UIView], _ selectedIndexes: [Int]) -> Void = { _, _ in }
    public var didSelectIndexes: (_ selectedIndexes: [Int]) -> Void = { _ in }
    
    public func setup(selectedIndexes: [Int]) {
        self.selectedIndexes = selectedIndexes
        self.didSelect()
    }
    
    public func setup(items: [UIView]) {
        self.items = items
        self.items.forEach({
            $0.addGestureRecognizer(UITapGestureRecognizer(
                target: self,
                action: #selector (self.tapAction(_:))
            ))
        })
        self.didSelect()
    }
    
    // MARK: - Lifecycle
    init(multipleSelectedEnable: Bool, allDeselectedEnable: Bool) {
        self.multipleSelectedEnable = multipleSelectedEnable
        self.allDeselectedEnable = allDeselectedEnable
    }
    
    // MARK: - Private
    private let multipleSelectedEnable: Bool
    private let allDeselectedEnable: Bool
    
    private var selectedIndexes: [Int] = []
    private var items: [UIView] = []
    
    private func didSelect() {
        self.didSelectItems(self.items, self.selectedIndexes)
        self.didSelectIndexes(self.selectedIndexes)
    }
    
    // MARK: - Action
    @objc
    private func tapAction(_ gesture: UITapGestureRecognizer) {
        guard
            let view = gesture.view,
            let index = self.items.firstIndex(of: view)
        else { return }
        
        if let selectedIndex = self.selectedIndexes.firstIndex(of: index) {
            if self.allDeselectedEnable {
                self.selectedIndexes.remove(at: selectedIndex)
            }
            else if self.multipleSelectedEnable, self.selectedIndexes.count > 1 {
                self.selectedIndexes.remove(at: selectedIndex)
            }
        }
        else {
            if !self.multipleSelectedEnable {
                self.selectedIndexes.removeAll()
            }
            self.selectedIndexes.append(index)
        }

        self.didSelect()
    }
    
}
