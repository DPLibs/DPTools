import Foundation
import UIKit

protocol FieldConfigurator {
    var minLength: Int? { get }
    var maxLength: Int? { get }
    var fixSpaceTextAlignmentRight: Bool { get }
    
    var keyboardType: UIKeyboardType { get }
    var autocapitalizationType: UITextAutocapitalizationType { get }
    var clearButtonMode: UITextField.ViewMode { get }
    var isSecureTextEntry: Bool { get }
    var autocorrectionType: UITextAutocorrectionType { get }
}

struct DefaultTextFieldConfiguration: FieldConfigurator {
    var minLength: Int? = 2
    var maxLength: Int? = 5
    var fixSpaceTextAlignmentRight: Bool = true
    var keyboardType: UIKeyboardType = .default
    var autocapitalizationType: UITextAutocapitalizationType = .none
    var clearButtonMode: UITextField.ViewMode = .never
    var isSecureTextEntry: Bool = false
    var autocorrectionType: UITextAutocorrectionType = .default
}

//enum FieldEvent: Int {
//    case didMinLength = 1
//    case didMaxLength = 2
//}
//
//extension UIControl.Event {
//    static let didMinLength = UIControl.Event(rawValue: 0b0001 << 24)
//    static let didMaxLength = UIControl.Event(rawValue: 0b0010 << 24)
//}

extension UITextField {
    
    func setup(configuration: FieldConfigurator) {
        self.keyboardType = configuration.keyboardType
        self.autocapitalizationType = configuration.autocapitalizationType
        self.clearButtonMode = configuration.clearButtonMode
        self.isSecureTextEntry = configuration.isSecureTextEntry
        self.autocorrectionType = configuration.autocorrectionType
    }
    
    func replace(replaceString: String, newString: String, fragmentReplacement fragment: String, rangeReplacement range: NSRange) {
        guard
            fragment.contains(replaceString),
            let replaceStart = self.position(from: self.beginningOfDocument, offset: range.location),
            let replaceEnd = self.position(from: replaceStart, offset: range.length),
            let textRange = self.textRange(from: replaceStart, to: replaceEnd)
        else { return }
        self.replace(textRange, withText: fragment.replacingOccurrences(of: replaceString, with: newString))
    }
    
}

class TextFieldAdapter: NSObject {
    
    weak var textField: UITextField? {
        didSet {
            self.textField?.delegate = self
            self.textField?.setup(configuration: self.configuration)
            self.textField?.addTarget(self, action: #selector(self.editingChanged(_:)), for: .editingChanged)
        }
    }
    
    private let configuration: FieldConfigurator
    
    init(configuration: FieldConfigurator) {
        self.configuration = configuration
    }
    
    public var didControlEvent: (_ event: UIControl.Event, _ value: String?) -> Void = { _, _ in }
    public var tapClearBtn: () -> Void = {}
    
    private func provide(controlEvent event: UIControl.Event) {
        self.didControlEvent(event, self.textField?.text)
    }
    
    @objc
    private func editingChanged(_ textField: UITextField) {
        self.provide(controlEvent: .editingChanged)
    }
    
}

// MARK: - UITextFieldDelegate
extension TextFieldAdapter: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
//        self.provideHandlers(.editingDidBegin)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
//        self.provideHandlers(.editingDidEnd)
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
//        self.tapClearBtn()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let text = textField.text else { return true }
        let newLength = text.count - range.length + string.count
        if let minLength = self.configuration.minLength, newLength < minLength {
//            self.provideEvent(.didMinLength)
        }
        if let maxLength = self.configuration.maxLength, newLength > maxLength {
//            self.provideEvent(.didMaxLength)
            return false
        }
        if self.configuration.fixSpaceTextAlignmentRight, string.contains(" "), textField.textAlignment == .right {
            textField.replace(replaceString: " ", newString: "\u{00a0}", fragmentReplacement: string, rangeReplacement: range)
            return false
        }
        return true
    }
    
}
