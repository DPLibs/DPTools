//
//  CameraAdapter.swift
//  dobro_2.0
//
//  Created by Дмитрий Поляков on 23.04.2020.
//  Copyright © 2020 Appcraft. All rights reserved.
//

import Foundation
import AVFoundation
import UIKit

protocol CameraAdapterInput: AnyObject {
    var didPosition: (_ position: AVCaptureDevice.Position) -> Void { get set }
    var didTorch: (_ torchMode: AVCaptureDevice.TorchMode) -> Void { get set }
    var didPhoto: (_ photo: Data) -> Void { get set }
//    var didVideo: (_ video: URL) -> Void { get set }
    
    func setContainer(_ container: UIView)
    func previewLayerUpdateSize()
    func togglePosition()
    func toggleTorch()
    func updateTorch(needTorchMode: AVCaptureDevice.TorchMode)
    func photoCapture()
//    func videoRecordStart()
//    func videoRecordStop()
}

class CameraAdapter: NSObject, CameraAdapterInput {
    
    // MARK: - Property
    enum Constants {
        static let dispatchQueueLabel = "camera_adapter_session_queue"
//        static let tempVideoFileName = "camera_adapter_temp_video"
//        static let tempVideoFileExtension = "mov"
    }
    
    private let session: AVCaptureSession
    private let previewLayer: AVCaptureVideoPreviewLayer
    private let sessionQueue: DispatchQueue
    private let photoOutput: AVCapturePhotoOutput
    private let movieOutput: AVCaptureMovieFileOutput
    
    private var needPosition: AVCaptureDevice.Position
    private var needTorchMode: AVCaptureDevice.TorchMode
    
    private var device: AVCaptureDevice?
    private var input: AVCaptureDeviceInput?
    
    private var photo: Data?
//    private var videoUrlList: [URL] = []
    
    weak var container: UIView? {
        didSet {
            self.didSetContainer()
        }
    }
    
    // MARK: - Lifecycle
    deinit {
        self.clearCashe()
    }
    
    init(needPosition: AVCaptureDevice.Position = .back, needTorchMode: AVCaptureDevice.TorchMode = .off) {
        self.session = AVCaptureSession()
        self.previewLayer = AVCaptureVideoPreviewLayer(session: self.session)
        self.sessionQueue = DispatchQueue(label: Constants.dispatchQueueLabel)
        self.photoOutput = AVCapturePhotoOutput()
        self.movieOutput = AVCaptureMovieFileOutput()
        self.needPosition = needPosition
        self.needTorchMode = needTorchMode
        super.init()
    
        self.sessionQueue.async {
            self.sessionConfigure()
            self.session.startRunning()
        }
    }
    
    private func sessionConfigure() {
        guard
            let device = self.createDevice(by: self.needPosition),
            let input = self.createInput(by: device)
//            let inputAudio = self.createInputAudio()
        else { return }
        self.device = device
        self.input = input
        
        self.session.beginConfiguration()
        self.session.addInput(input)
//        self.session.addInput(inputAudio)
        self.session.addOutput(self.photoOutput)
        self.session.addOutput(self.movieOutput)
        self.session.commitConfiguration()
    }
    
    private func createDevice(by position: AVCaptureDevice.Position) -> AVCaptureDevice? {
        AVCaptureDevice.DiscoverySession(
            deviceTypes: [.builtInDualCamera, .builtInTelephotoCamera, .builtInWideAngleCamera],
            mediaType: .video,
            position: position
        ).devices.first
    }
    
    private func createInput(by device: AVCaptureDevice) -> AVCaptureDeviceInput? {
        try? AVCaptureDeviceInput(device: device)
    }
    
//    private func createInputAudio() -> AVCaptureDeviceInput? {
//        guard let device = AVCaptureDevice.default(for: .audio) else { return nil }
//        return try? AVCaptureDeviceInput(device: device)
//    }
    
    private func didSetContainer() {
        let videoOrientation: AVCaptureVideoOrientation
        switch UIInterfaceOrientation(rawValue: UIApplication.shared.statusBarOrientation.rawValue) ?? .portrait {
        case .landscapeLeft:
            videoOrientation = .landscapeLeft
        case .landscapeRight:
            videoOrientation = .landscapeRight
        case .portraitUpsideDown:
            videoOrientation = .portraitUpsideDown
        default:
            videoOrientation = .portrait
        }
        self.previewLayer.connection?.videoOrientation = videoOrientation
        self.previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        
        self.container?.layer.addSublayer(self.previewLayer)
        self.previewLayerUpdateSize()
    }
    
    private func clearCashe() {
//        for url in self.videoUrlList {
//            if FileManager.default.fileExists(atPath: url.path) {
//                try? FileManager.default.removeItem(atPath: url.path)
//            }
//        }
    }
    
    // MARK: - Input
    var didPosition: (_ position: AVCaptureDevice.Position) -> Void = { _ in }
    var didTorch: (_ torchMode: AVCaptureDevice.TorchMode) -> Void = { _ in }
    var didPhoto: (_ photo: Data) -> Void = { _ in }
//    var didVideo: (_ video: URL) -> Void = { _ in }
    
    func setContainer(_ container: UIView) {
        self.container = container
    }
    
    func previewLayerUpdateSize() {
        self.previewLayer.frame.size = self.container?.frame.size ?? .zero
    }
    
    func togglePosition() {
        guard let currentPosition = self.device?.position else { return }
        
        let position: AVCaptureDevice.Position
        switch currentPosition {
        case .back:
            position = .front
        case .front:
            position = .back
        case .unspecified:
            return
        @unknown default:
            return
        }
        
        guard
            let device = self.createDevice(by: position),
            let input = self.createInput(by: device)
        else {
            self.didPosition(currentPosition)
            return
        }
        
        self.session.beginConfiguration()
        self.session.inputs.forEach({
            self.session.removeInput($0)
        })
        self.session.addInput(input)
        self.session.commitConfiguration()
        
        self.device = device
        self.input = input
        self.needPosition = position
        self.didPosition(position)
        self.updateTorch(needTorchMode: self.needTorchMode)
    }
    
    func toggleTorch() {
        guard self.device?.hasTorch == true, let currentTorchMode = self.device?.torchMode else { return }
        let torchMode: AVCaptureDevice.TorchMode
        switch currentTorchMode {
        case .auto,
             .on:
            torchMode = .off
        case .off:
            torchMode = .on
        @unknown default:
            return
        }
        self.updateTorch(needTorchMode: torchMode)
    }
    
    func updateTorch(needTorchMode: AVCaptureDevice.TorchMode) {
        guard self.device?.hasTorch == true else {
            self.didTorch(.off)
            return
        }
        do {
            try self.device?.lockForConfiguration()
            self.device?.torchMode = needTorchMode
            self.device?.unlockForConfiguration()
        }
        catch {}
        self.needTorchMode = needTorchMode
        self.didTorch(needTorchMode)
    }
    
    func photoCapture() {
        self.sessionQueue.async { [weak self] in
            guard let self = self else { return }
            self.photoOutput.capturePhoto(with: AVCapturePhotoSettings(), delegate: self)
        }
    }
    
//    func videoRecordStart() {
//        self.sessionQueue.async { [weak self] in
//            guard let self = self else { return }
//            let fileName = UUID().uuidString
//            let tempPath = URL(fileURLWithPath: NSTemporaryDirectory())
//                .appendingPathComponent(fileName)
//                .appendingPathExtension(Constants.tempVideoFileExtension)
//            if FileManager.default.fileExists(atPath: tempPath.path) {
//                try? FileManager.default.removeItem(atPath: tempPath.path)
//            }
//            self.videoUrlList.append(tempPath)
//            self.movieOutput.startRecording(to: tempPath, recordingDelegate: self)
//        }
//    }
//
//    func videoRecordStop() {
//        self.sessionQueue.async { [weak self] in
//            guard let self = self else { return }
//            self.movieOutput.stopRecording()
//        }
//    }
    
}

// MARK: - AVCapturePhotoCaptureDelegate
extension CameraAdapter: AVCapturePhotoCaptureDelegate {
    
    func photoOutput(_ output: AVCapturePhotoOutput, willCapturePhotoFor resolvedSettings: AVCaptureResolvedPhotoSettings) {
      self.previewLayer.opacity = 0
      UIView.animate(withDuration: 0.25) {
        self.previewLayer.opacity = 1
      }
    }
    
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        guard error == nil else { return }
        self.photo = photo.fileDataRepresentation()
    }
    
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishCaptureFor resolvedSettings: AVCaptureResolvedPhotoSettings, error: Error?) {
        guard error == nil else { return }
        guard let photo = self.photo else { return }
        self.didPhoto(photo)
    }
    
}

// MARK: - AVCaptureFileOutputRecordingDelegate
//extension CameraAdapter: AVCaptureFileOutputRecordingDelegate {
    
//    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
//        self.didVideo(outputFileURL)
//    }
    
//}
