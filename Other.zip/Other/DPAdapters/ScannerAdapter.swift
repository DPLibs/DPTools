//import Foundation
//import AVFoundation
//import UIKit
//
//protocol ScannerAdapterInput {
//    var output: ScannerAdapterOutput? { get set }
//    var scannerView: UIView? { get set }
//    var coverView: UIImageView? { get set }
//    
//    var didScanned: (_ data: String) -> Void { get set }
//    var didStartRunning: () -> Void { get set }
//    var didStopRunning: () -> Void { get set }
//    
//    var torchIsEnaled: Bool { get }
//    
//    func setup()
//    func updateOrientation()
//    func requestAccess(completion: @escaping (AVAuthorizationStatus) -> Void)
//    func startRunning()
//    func stopRunning()
//    func updateScannerFrame(_ view: UIView)
//    func updateTorch(needTorchMode: AVCaptureDevice.TorchMode)
//    func toggleTorch()
//}
//
//protocol ScannerAdapterOutput: AnyObject {
//    func error(adapter: ScannerAdapter, error: AppMessage)
//    func scanned(adapter: ScannerAdapter, data: String)
//}
//
//class ScannerAdapter: NSObject, ScannerAdapterInput {
//    
//    weak var output: ScannerAdapterOutput?
//    
//    weak var scannerView: UIView? {
//        didSet {
//            self.setupScannerLayer()
//        }
//    }
//    weak var coverView: UIImageView?
//    
//    var didScanned: (_ data: String) -> Void = { _ in }
//    var didStartRunning: () -> Void = {}
//    var didStopRunning: () -> Void = {}
//    
//    private var captureSession: AVCaptureSession?
//    private var scannerLayer: AVCaptureVideoPreviewLayer?
//    private var metadataOutput: AVCaptureMetadataOutput?
//    private var videoCaptureDevice: AVCaptureDevice?
//    
//    private var orientation: AVCaptureVideoOrientation
//    private let context: CIContext
//
//    override init() {
//        self.orientation = .portrait
//        self.context = CIContext()
//    }
//    
//    public func setup() {
//        let captureSession = AVCaptureSession()
//
//        guard let videoCaptureDevice = AVCaptureDevice.default(for: .video), let videoInput = try? AVCaptureDeviceInput(device: videoCaptureDevice) else { return }
//        self.videoCaptureDevice = videoCaptureDevice
//        let metadataOutput = AVCaptureMetadataOutput()
//        let videoOutput = AVCaptureVideoDataOutput()
//
//        guard captureSession.canAddInput(videoInput), captureSession.canAddOutput(metadataOutput), captureSession.canAddOutput(videoOutput) else {
//            self.provideError(AppMessage.deniedCameraAccess)
//            return
//        }
//        captureSession.addInput(videoInput)
//        captureSession.addOutput(metadataOutput)
//        metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
//        metadataOutput.metadataObjectTypes = [.ean8, .ean13, .upce]
//        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "sample_buffer_delegate", attributes: []))
//        captureSession.addOutput(videoOutput)
//
//        self.scannerLayer = AVCaptureVideoPreviewLayer(session: captureSession)
//        self.setupScannerLayer()
//        self.metadataOutput = metadataOutput
//        self.captureSession = captureSession
//        self.captureSession?.commitConfiguration()
//        self.captureSession?.startRunning()
//        
//        self.updateTorch(needTorchMode: .auto)
//    }
//    
//    public func updateOrientation() {
//        guard let orientation = AVCaptureVideoOrientation(rawValue: UIApplication.shared.statusBarOrientation.rawValue) else { return }
//        self.orientation = orientation
//    }
//    
//    func updateTorch(needTorchMode: AVCaptureDevice.TorchMode) {
//        guard self.videoCaptureDevice?.hasTorch == true else { return }
//        do {
//            try self.videoCaptureDevice?.lockForConfiguration()
//            self.videoCaptureDevice?.torchMode = needTorchMode
//            self.videoCaptureDevice?.unlockForConfiguration()
//        }
//        catch {}
//    }
//    
//    func toggleTorch() {
//        guard self.videoCaptureDevice?.hasTorch == true, let current = self.videoCaptureDevice?.torchMode else { return }
//        var need: AVCaptureDevice.TorchMode
//        switch current {
//        case .auto,
//             .on:
//            need = .off
//        case .off:
//            need = .on
//        @unknown default:
//            need = .off
//        }
//        self.updateTorch(needTorchMode: need)
//    }
//    
//    var torchIsEnaled: Bool {
//        guard self.videoCaptureDevice?.hasTorch == true, let current = self.videoCaptureDevice?.torchMode else { return false }
//        switch current {
//        case .auto,
//             .on:
//            return true
//        case .off:
//            return false
//        @unknown default:
//            return false
//        }
//    }
//    
//    public func startRunning() {
//        guard self.captureSession?.isRunning == false else { return }
//        self.captureSession?.startRunning()
//        self.didStartRunning()
//    }
//    
//    public func stopRunning() {
//        guard self.captureSession?.isRunning == true else { return }
//        self.captureSession?.stopRunning()
//        self.didStopRunning()
//    }
//    
//    public func requestAccess(completion: @escaping (AVAuthorizationStatus) -> Void) {
//        guard AVCaptureDevice.authorizationStatus(for: AVMediaType.video) != .authorized else { return }
//        AVCaptureDevice.requestAccess(for: AVMediaType.video, completionHandler: { authorized in
//            completion(AVCaptureDevice.authorizationStatus(for: AVMediaType.video))
//            guard authorized else { return }
//            DispatchQueue.main.async { [weak self] in
//                self?.setup()
//            }
//        })
//    }
//    
//    public func updateScannerFrame(_ view: UIView) {
//        DispatchQueue.main.async { [weak self] in
//            guard let self = self else { return }
//            self.scannerLayer?.frame = view.layer.bounds
////            guard let layer = self.scannerLayer else { return }
////            self.metadataOutput?.rectOfInterest = layer.metadataOutputRectConverted(fromLayerRect: view.layer.bounds)
//        }
//    }
//    
//    private func setupScannerLayer() {
//        guard let layer = self.scannerLayer, let view = self.scannerView else { return }
//        layer.removeFromSuperlayer()
//        layer.frame = view.layer.bounds
//        layer.videoGravity = .resizeAspectFill
//        view.layer.addSublayer(layer)
//    }
//    
//    private func provideError(_ error: AppMessage) {
//        self.output?.error(adapter: self, error: error)
//        self.captureSession = nil
//    }
//}
//
//// MARK: - AVCaptureMetadataOutputObjectsDelegate
//extension ScannerAdapter: AVCaptureMetadataOutputObjectsDelegate {
//    
//    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
//        guard
//            let metadataObject = metadataObjects.first,
//            let readableObject = metadataObject as? AVMetadataMachineReadableCodeObject,
//            let stringValue = readableObject.stringValue
//        else { return }
//        AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
//        self.output?.scanned(adapter: self, data: stringValue)
//        self.didScanned(stringValue)
//    }
//}
//
//// MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
//extension ScannerAdapter: AVCaptureVideoDataOutputSampleBufferDelegate {
//
//    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
//        guard self.coverView != nil else { return }
//        connection.videoOrientation = self.orientation
//        let videoOutput = AVCaptureVideoDataOutput()
//        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue.main)
//        
//        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
//        let cameraImage = CIImage(cvImageBuffer: pixelBuffer)
//        
//        let blur = CIFilter(name: "CIGaussianBlur")
//        blur?.setValue(cameraImage, forKey: kCIInputImageKey)
//        blur?.setValue(20.0, forKey: kCIInputRadiusKey)
//        
//        guard let outputImage = blur?.outputImage else { return }
//        guard let cgImage = self.context.createCGImage(outputImage, from: cameraImage.extent) else { return }
//        
//        DispatchQueue.main.async { [weak self ] in
//            self?.coverView?.image = UIImage(cgImage: cgImage)
//        }
//        
//    }
//}
