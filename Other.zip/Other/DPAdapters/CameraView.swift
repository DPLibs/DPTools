//
//  CameraView.swift
//  BeeO
//
//  Created by mac mini on 13.07.2020.
//  Copyright © 2020 AppCraft. All rights reserved.
//

import Foundation
import UIKit

class CameraView: UIView {
    
    weak var adapter: CameraAdapterInput? {
        didSet {
            self.adapter?.setContainer(self)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.adapter?.previewLayerUpdateSize()
    }
    
}
