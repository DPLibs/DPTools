////
////  VideoAdapter.swift
////  dobro_2.0
////
////  Created by Дмитрий Поляков on 26.04.2020.
////  Copyright © 2020 Appcraft. All rights reserved.
////
//
//import Foundation
//import UIKit
//import AVKit
//import AVFoundation
//import DPLibrary
//
//class VideoAdapter {
//    
//    enum Constants {
//        static let fileName = "video_adapter_file_name"
//        static let fileExtension = "mp4"
//    }
//    
//    // MARK: - Lifecycle
//    deinit {
//        NotificationCenter.default.removeObserver(self)
//        self.fileUtil.remove(url: self.destination)
//        self.removePeriodicTimeObserver()
//    }
//    
//    init() {
//        self.playerLayer = AVPlayerLayer()
//        self.fileUtil = FileUtil()
//        self.destination = self.fileUtil.destinationTempUrl(Constants.fileName, Constants.fileExtension)
//    }
//    
//    // MARK: - Private
//    private let fileUtil: FileUtil
//    private let playerLayer: AVPlayerLayer
//    private let destination: URL
//    
//    private var player: AVPlayer?
//    private var timeObserverToken: Any?
//    
//    private func didSetContainer() {
//        self.playerLayer.videoGravity = AVLayerVideoGravity.resize
//        self.container?.layer.addSublayer(self.playerLayer)
//        self.playerLayerUpdateSize()
//    }
//
//    private func removePeriodicTimeObserver() {
//        guard let timeObserverToken = self.timeObserverToken else { return }
//        self.player?.removeTimeObserver(timeObserverToken)
//        self.timeObserverToken = nil
//    }
//    
//    // MARK: - Public
//    weak var container: UIView? {
//        didSet {
//            self.didSetContainer()
//        }
//    }
//    
//    public var isLoop: Bool = false
//    public var timeStep: TimeInterval = 0.1
//    
//    public var didEnd: () -> Void = {}
//    public var didTime: (TimeInterval) -> Void = { _ in }
//    public var didProgress: (Float) -> Void = { _ in }
//    
//    public var isPlayed: Bool {
//        self.player?.timeControlStatus == .playing
//    }
//    
//    public func playerLayerUpdateSize() {
//        guard let size = self.container?.frame.size else { return }
//        self.playerLayer.frame.size = size
//    }
//    
//    public func setup(data: Data?) {
//        guard let data = data else { return }
//        try? data.write(to: self.destination)
//        self.setup(url: self.destination)
//    }
//    
//    public func setup(url: URL?) {
//        guard let videoURL = url else { return }
//        self.player = AVPlayer(url: videoURL)
//        self.playerLayer.player = self.player
//        NotificationCenter.default.addObserver(
//            self,
//            selector: #selector(self.didAVPlayerItemDidPlayToEndTime(_:)),
//            name: NSNotification.Name.AVPlayerItemDidPlayToEndTime,
//            object: self.player?.currentItem
//        )
//        
//        let time = CMTime(seconds: self.timeStep, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
//        self.timeObserverToken = player?.addPeriodicTimeObserver(forInterval: time, queue: .main) { [weak self] time in
//            self?.provideDidTime(time)
//        }
//    }
//    
//    public func updateState(_ value: PlayState) {
//        switch value {
//        case .play:
//            self.play()
//        case .pause:
//            self.pause()
//        case .stop:
//            self.stop()
//        }
//    }
//    
//    public func play() {
//        guard !isPlayed else { return }
//        self.player?.play()
//    }
//    
//    public func pause() {
//        self.player?.pause()
//    }
//    
//    public func stop() {
//        self.player?.pause()
//        self.player?.seek(to: CMTime.zero)
//    }
//    
//    // MARK: - Action
//    @objc
//    private func didAVPlayerItemDidPlayToEndTime(_ notification: Notification) {
//        self.didEnd()
//        guard self.isLoop else { return }
//        self.player?.pause()
//        self.player?.seek(to: CMTime.zero)
//        self.player?.play()
//    }
//    
//    private func provideDidTime(_ time: CMTime) {
//        guard self.isPlayed else { return }
//        let seconds = time.seconds
//        self.didTime(seconds)
//        let duration = self.player?.currentItem?.duration.seconds ?? 0
//        let progress = duration > 0 ? seconds / duration : 0
//        self.didProgress(Float(progress))
//    }
//    
//}
