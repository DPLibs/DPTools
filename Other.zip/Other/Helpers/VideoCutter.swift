//
//  VideoCutter.swift
//  dobro_2.0
//
//  Created by Дмитрий Поляков on 26.04.2020.
//  Copyright © 2020 Appcraft. All rights reserved.
//

import Foundation
import AVKit
import AVFoundation

class VideoCutter {
    
    enum Constants {
        static let fileName = "video_cutter_file_name"
        static let fileExtension = "mp4"
    }
    
    private var start: TimeInterval = 0.0
    private var splitList: [URL] = []
    public var didEnd: ([URL]) -> Void = { _ in }
    
    private let videoUrl: URL
    private let fragmentDuration: TimeInterval
    
    deinit {
        self.clearCashe()
    }
    
    init(videoUrl: URL, fragmentDuration: TimeInterval) {
        self.videoUrl = videoUrl
        self.fragmentDuration = fragmentDuration
    }
    
    private func finish() {
        if self.splitList.isEmpty {
            self.splitList.append(self.videoUrl)
        }
        self.didEnd(self.splitList)
    }
    
    public func split() {
        let asset = AVAsset(url: self.videoUrl)
        let videoDuration = CMTimeGetSeconds(asset.duration)
        print("%%%%%%%%%%", videoDuration)
        
        let end: TimeInterval = videoDuration <= self.start + self.fragmentDuration ? videoDuration : self.start + self.fragmentDuration
        print("((()))))))", videoDuration)
        let timeRange = CMTimeRange(
            start: CMTime(seconds: self.start * 1000, preferredTimescale: 1000),
            end: CMTime(seconds: end * 1000, preferredTimescale: 1000)
        )
        
        guard videoDuration > self.start else {
            self.finish()
            return
        }
        
        let tempPath = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension(Constants.fileExtension)
        if FileManager.default.fileExists(atPath: tempPath.path) {
            try? FileManager.default.removeItem(atPath: tempPath.path)
        }
        
        guard let exportSession = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality) else {
            self.finish()
            return
        }
        exportSession.outputURL = tempPath
        exportSession.outputFileType = .mp4
        exportSession.timeRange = timeRange
        exportSession.exportAsynchronously {
            guard exportSession.status == .completed else {
                self.finish()
                return
            }
            self.splitList.append(tempPath)
            self.start += self.fragmentDuration
            self.split()
        }
    }
    
    public func clearCashe() {
        for url in self.splitList {
            if FileManager.default.fileExists(atPath: url.path) {
                try? FileManager.default.removeItem(atPath: url.path)
            }
        }
    }
    
}
