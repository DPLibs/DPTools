////
////  VideoSplitter.swift
////  dobro_2.0
////
////  Created by Дмитрий Поляков on 27.04.2020.
////  Copyright © 2020 Appcraft. All rights reserved.
////
//
//import Foundation
//import AVFoundation
//import UIKit
//
//class VideoSplitter {
//    
//    // MARK: - Static
//    typealias SplitCompletion = (_ destinationList: [URL]) -> Void
//    
//    // MARK: - Lifecycle
//    deinit {
////        self.fileUtil.removeList(urlList: self.destinationList)
//    }
//    
//    init() {
//        self.fileUtil = FileUtil()
//        self.trimmer = VideoTrimmer()
//    }
//    
//    // MARK: - Private
//    private let fileUtil: FileUtil
//    private let trimmer: VideoTrimmer
//    private var destinationList: [URL] = []
//    
//    // MARK: - Public
//    func split(source: URL, duration: TimeInterval, completion: @escaping SplitCompletion) {
//        let asset = AVAsset(url: source)
//        let fullDuration = CMTimeGetSeconds(asset.duration)
//        var points: [VideoTrimmer.Point] = []
//        let count = Int(fullDuration / duration) + 1
//        var start: TimeInterval = .zero
//        for _ in 1...count {
//            let end = start + duration >= fullDuration ? fullDuration : start + duration
//            points.append(VideoTrimmer.Point(start: start, end: end))
//            start = end
//        }
//        
//        var destinationList: [URL] = []
//        var completionCounter: Int = .zero
//        
//        for point in points {
//            let destination = self.fileUtil.destinationTempUrl(UUID().uuidString, "mp4")
//            destinationList.append(destination)
//            self.trimmer.trim(source: source, destination: destination, points: [point]) { [weak self] _, _ in
//                completionCounter += 1
//                guard completionCounter == count else { return }
//                completion(destinationList)
//                self?.destinationList = destinationList
//            }
//        }
//    }
//    
//}
