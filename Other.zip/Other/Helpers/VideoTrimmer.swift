////
////  VideoTrimmer.swift
////  dobro_2.0
////
////  Created by Дмитрий Поляков on 27.04.2020.
////  Copyright © 2020 Appcraft. All rights reserved.
////
//
//import Foundation
//import AVFoundation
//import UIKit
//
//class VideoTrimmer {
//    
//    // MARK: - Static
//    typealias TrimCompletion = (_ destination: URL, _ error: Error?) -> Void
//    
//    enum Errors {
//        static let verifyPresetForAsset = AppMessage.undefined
//    }
//    
//    struct Point {
//        let start: TimeInterval
//        let end: TimeInterval
//        
//        let startTime: CMTime
//        let endTime: CMTime
//        let timeScale: Int32 = 1000
//        
//        init(start: TimeInterval, end: TimeInterval) {
//            self.start = start
//            self.end = end
//            self.startTime = CMTimeMake(
//                value: Int64(start * Double(self.timeScale)),
//                timescale: self.timeScale
//            )
//            self.endTime = CMTimeMake(
//                value: Int64(end * Double(self.timeScale)),
//                timescale: self.timeScale
//            )
//        }
//    }
//    
//    // MARK: - Lifecycle
//    init() {
//        self.fileUtil = FileUtil()
//    }
//    
//    // MARK: - Private
//    private let fileUtil: FileUtil
//    
//    private func verifyPresetForAsset(preset: String, asset: AVAsset) -> Bool {
//        let compatiblePresets = AVAssetExportSession.exportPresets(compatibleWith: asset)
//        let filteredPresets = compatiblePresets.filter { $0 == preset }
//        return !filteredPresets.isEmpty || preset == AVAssetExportPresetPassthrough
//    }
//    
//    // MARK: - Public
//    public func trim(source: URL, destination: URL, points: [Point], completion: TrimCompletion?) {
//        guard source.isFileURL, destination.isFileURL else {
//            completion?(destination, nil)
//            return
//        }
//        
//        let options = [AVURLAssetPreferPreciseDurationAndTimingKey: true]
//        let preset = AVAssetExportPresetPassthrough
//        let asset = AVURLAsset(url: source, options: options)
//        
//        guard self.verifyPresetForAsset(preset: preset, asset: asset) else {
//            completion?(destination, Errors.verifyPresetForAsset)
//            return
//        }
//            
//        let composition = AVMutableComposition()
//        let videoCompTrack = composition.addMutableTrack(withMediaType: .video, preferredTrackID: CMPersistentTrackID())
//        let audioCompTrack = composition.addMutableTrack(withMediaType: .audio, preferredTrackID: CMPersistentTrackID())
//        
//        guard
//            let assetVideoTrack: AVAssetTrack = asset.tracks(withMediaType: .video).first,
//            let assetAudioTrack: AVAssetTrack = asset.tracks(withMediaType: .audio).first
//        else {
//            completion?(destination, nil)
//            return
//        }
//
//        videoCompTrack?.preferredTransform = assetVideoTrack.preferredTransform
//        
//        var accumulatedTime = CMTime.zero
//        for point in points {
//            let duration = CMTimeSubtract(point.endTime, point.startTime)
//            let timeRange = CMTimeRangeMake(start: point.startTime, duration: duration)
//            do {
//                try videoCompTrack?.insertTimeRange(timeRange, of: assetVideoTrack, at: accumulatedTime)
//                try audioCompTrack?.insertTimeRange(timeRange, of: assetAudioTrack, at: accumulatedTime)
//                accumulatedTime = CMTimeAdd(accumulatedTime, duration)
//            }
//            catch let error {
//                completion?(destination, error)
//            }
//        }
//        
//        self.fileUtil.remove(url: destination)
//        guard let exportSession = AVAssetExportSession(asset: composition, presetName: preset) else {
//            completion?(destination, nil)
//            return
//        }
//        exportSession.outputURL = destination
//        exportSession.outputFileType = AVFileType.m4v
//        exportSession.shouldOptimizeForNetworkUse = true
//        exportSession.exportAsynchronously {
//            completion?(destination, exportSession.error)
//        }
//    }
//    
//}
