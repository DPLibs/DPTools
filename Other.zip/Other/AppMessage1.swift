//
//  AppMessage1.swift
//  PlaygroundIOS
//
//  Created by mac mini on 16.06.2021.
//  Copyright © 2021 Дмитрий Поляков. All rights reserved.
//

import Foundation

#warning("Create Pod DPMessage")
//public struct Message {
//
//    // MARK: - Static
//    public enum IdentiferType {
//        case code(_ value: Int)
//        case string(_ value: String)
//
//        var code: Int {
//            switch self {
//            case let .code(value):
//                return value
//            case let .string(value):
//                return value.toInt ?? 0
//            }
//        }
//
//        var string: String {
//            switch self {
//            case let .code(value):
//                return value.description.lowercased()
//            case let .string(value):
//                return value.lowercased()
//            }
//        }
//    }
//
//    public enum TitleType {
//        case none
//        case error
//        case info
//        case custom(_ text: String)
//
//        public var text: String? {
//            switch self {
//            case .none:
//                return nil
//            case .error:
//                return NSLocalizedString("error", comment: "")
//            case .info:
//                return NSLocalizedString("info", comment: "")
//            case let .custom(text):
//                return text
//            }
//        }
//    }
//
//    public static let defaults = MessageStore()
//
//    public fileprivate(set) static var storedMessages: [Message] = []
//
//    // MARK: - Props
//    public let identifer: String
//    public let code: Int
//    public let message: String
//    public let title: String?
//    public let userData: Any?
//
//    // MARK: - Init
//    init(
//        identifer: IdentiferType,
//        message: String,
//        title: TitleType,
//        userData: Any? = nil
//    ) {
//        self.identifer = identifer.string
//        self.code = identifer.code
//        self.message = message
//        self.title = title.text
//        self.userData = userData
//    }
//
//    static func error(identifer: IdentiferType, message: String, userData: Any? = nil) -> Message {
//        .init(identifer: identifer, message: message, title: .error, userData: userData)
//    }
//
//    static func info(identifer: IdentiferType, message: String, userData: Any? = nil) -> Message {
//        .init(identifer: identifer, message: message, title: .info, userData: userData)
//    }
//
//    static func findOrInit(by error: Error?) -> Message? {
//        guard let error = error else { return nil }
//
//        let code = (error as? Message)?.code ?? (error as NSError).code
//
//        if let message = self.storedMessages.first(where: { $0.identifer == code.description }) {
//            return message
//        } else {
//            return .error(identifer: .code(code), message: error.localizedDescription)
//        }
//    }
//
//    static func find(by identifer: Message.IdentiferType?) -> Message? {
//        guard let identifer = identifer else { return nil }
//
//        return self.storedMessages.first(where: { $0.identifer == identifer.string })
//    }
//}
//
//// MARK: - Equatable
//extension Message: Equatable {
//
//    public static func == (lhs: Message, rhs: Message) -> Bool {
//        lhs.identifer.lowercased() == rhs.identifer.lowercased()
//    }
//
//}
//
//// MARK: - LocalizedError
//extension Message: LocalizedError {
//
//    public var errorDescription: String? {
//        self.message
//    }
//
//    public var failureReason: String? {
//        self.message
//    }
//
//}

//open class MessageStore {
//
//    public private(set) var wasConfigured: Bool = false
//
//    public func configure() {
//        guard !self.wasConfigured else {
//            fatalError("Was configured")
//        }
//
//        let mirror = Mirror(reflecting: self)
//
//        mirror.children.forEach({
//            guard let message = $0.value as? Message else { return }
//
//            guard !Message.storedMessages.contains(message) else {
//                fatalError("AppMessage with identifer = `\(message.identifer)` has already been created")
//            }
//
//            Message.storedMessages.appendUnique(message)
//        })
//
//        self.wasConfigured = true
//    }
//
//    public let undefined: Message = .error(identifer: .string("undefined"), message: "Неизвестная ошибка")
//
//}
//
//open class MessageHandler {
//
//    weak var controller: UIViewController?
//
//    open func showMessage(_ message: Message?) {
//        guard let message = message else { return }
//
//        switch message {
//        case .defaults.undefined:
//            break
//        default:
//            break
//        }
//    }
//
//}

//public struct AppMessage {
//    static func configure() {
//        guard !self.wasConfigured else {
//            fatalError("Was configured")
//        }
//
//        let mirror = Mirror(reflecting: AppMessage.messages)
//
//        mirror.children.forEach({
//            guard let message = $0.value as? AppMessage else { return }
//
//            guard !self.storedMessages.contains(message) else {
//                fatalError("AppMessage with identifer = `\(message.identifer)` has already been created")
//            }
//
//            self.storedMessages.appendUnique(message)
//        })
//
//        self.wasConfigured = true
//    }
//}

//// MARK: - Store
//public extension AppMessage.Messages {
//
//    // MARK: - Identifer: string - Title: none
//    let in_develop: AppMessage = .init(
//        identifer: .string("in_develop"),
//        message: R.string.localizable.am_in_develop(),
//        title: .none
//    )
//
//    let successfully: AppMessage = .init(
//        identifer: .string("successfully"),
//        message: R.string.localizable.am_successfully(),
//        title: .none
//    )
//
//    let app_exit_confirmed: AppMessage = .init(
//        identifer: .string("app_exit_confirmed"),
//        message: R.string.localizable.am_app_exit_confirmed(),
//        title: .none
//    )
//
//    let delete_profile_confirmed: AppMessage = .init(
//        identifer: .string("delete_profile_confirmed"),
//        message: R.string.localizable.am_delete_profile_confirmed(),
//        title: .none
//    )
//
//    let load_images: AppMessage = .init(
//        identifer: .string("load_images"),
//        message: R.string.localizable.am_load_images(),
//        title: .none
//    )
//
//    let load_data: AppMessage = .init(
//        identifer: .string("load_data"),
//        message: R.string.localizable.am_load_data(),
//        title: .none
//    )
//
//    let data_not_saved_confirmed: AppMessage = .init(
//        identifer: .string("data_not_saved_confirmed"),
//        message: R.string.localizable.am_data_not_saved_confirmed(),
//        title: .none
//    )
//
//    let user_not_found: AppMessage = .init(
//        identifer: .string("user_not_found"),
//        message: R.string.localizable.am_user_not_found(),
//        title: .none
//    )
//
//    let recover_pin_code_confirm: AppMessage = .init(
//        identifer: .string("recover_pin_code_confirm"),
//        message: R.string.localizable.am_recover_pin_code_confirm(),
//        title: .none
//    )
//
//    let break_register_confirm: AppMessage = .init(
//        identifer: .string("break_register_confirm"),
//        message: R.string.localizable.am_break_register_confirm(),
//        title: .none
//    )
//
//    let phone_number_busy: AppMessage = .init(
//        identifer: .string("phone_number_busy"),
//        message: R.string.localizable.am_phone_number_busy(),
//        title: .none
//    )
//
//    let file_will_be_delete_confirm: AppMessage = .init(
//        identifer: .string("file_will_be_delete_confirm"),
//        message: R.string.localizable.am_file_will_be_delete_confirm(),
//        title: .none
//    )
//
//    let user_with_username_not_found: AppMessage = .init(
//        identifer: .string("user_with_username_not_found"),
//        message: R.string.localizable.am_user_with_username_not_found(),
//        title: .none
//    )
//
//    let invalid_password: AppMessage = .init(
//        identifer: .string("invalid_password"),
//        message: R.string.localizable.am_invalid_password(),
//        title: .none
//    )
//
//    let passwords_mismatch: AppMessage = .init(
//        identifer: .string("passwords_mismatch"),
//        message: R.string.localizable.am_passwords_mismatch(),
//        title: .none
//    )
//
//    let fields_validation_error: AppMessage = .init(
//        identifer: .string("fields_validation_error"),
//        message: R.string.localizable.fields_validation_error(),
//        title: .none
//    )
//
//    // MARK: - Identifer: string - Title: custom
//    let promocode_success: AppMessage = .init(
//        identifer: .string("promocode_success"),
//        message: R.string.localizable.am_promocode_success_message(),
//        title: .custom(R.string.localizable.am_promocode_success_title())
//    )
//
//    // MARK: - Identifer: code - Title: error
//    let bad_request: AppMessage = .error(
//        identifer: .code(400),
//        message: R.string.localizable.am_bad_request()
//    )
//
//    let unauthorized: AppMessage = .error(
//        identifer: .code(401),
//        message: R.string.localizable.am_unauthorized()
//    )
//
//    let forbidden: AppMessage = .error(
//        identifer: .code(403),
//        message: R.string.localizable.am_forbidden()
//    )
//
//    let not_found: AppMessage = .error(
//        identifer: .code(404),
//        message: R.string.localizable.am_not_found()
//    )
//
//    let custom_detail_error: AppMessage = .error(
//        identifer: .code(499),
//        message: R.string.localizable.am_internal_server_error()
//    )
//
//    let internal_server_error: AppMessage = .error(
//        identifer: .code(500),
//        message: R.string.localizable.am_internal_server_error()
//    )
//
//    let bad_gateway: AppMessage = .error(
//        identifer: .code(502),
//        message: R.string.localizable.am_bad_gateway()
//    )
//
//    let cancelled: AppMessage = .error(
//        identifer: .code(-999),
//        message: R.string.localizable.am_cancelled()
//    )
//
//    let no_internet_connection: AppMessage = .error(
//        identifer: .code(-1009),
//        message: R.string.localizable.am_no_internet_connection()
//    )
//
//    let no_server_connection: AppMessage = .error(
//        identifer: .code(-1004),
//        message: R.string.localizable.am_no_server_connection()
//    )
//
//    // MARK: - Identifer: string - Title: error
//    let undefined: AppMessage = .error(
//        identifer: .string("undefined"),
//        message: R.string.localizable.am_undefined()
//    )
//
//    let denied_camera_access: AppMessage = .error(
//        identifer: .string("denied_camera_access"),
//        message: R.string.localizable.am_denied_camera_access()
//    )
//
//    let mail_services_not_available: AppMessage = .error(
//        identifer: .string("mail_services_not_available"),
//        message: R.string.localizable.am_mail_services_not_available()
//    )
//
//    let need_read_processing_personal_data: AppMessage = .error(
//        identifer: .string("need_read_processing_personal_data"),
//        message: R.string.localizable.am_need_read_processing_personal_data()
//    )
//
//    let need_read_terms_of_use: AppMessage = .error(
//        identifer: .string("need_read_terms_of_use"),
//        message: R.string.localizable.am_need_read_terms_of_use()
//    )
//
//    let need_read_personal_data_processing_policy: AppMessage = .error(
//        identifer: .string("need_read_personal_data_processing_policy"),
//        message: R.string.localizable.am_need_read_personal_data_processing_policy()
//    )
//
//    let method_not_found: AppMessage = .error(
//        identifer: .string("METHOD_NOT_FOUND"),
//        message: R.string.localizable.am_method_not_found()
//    )
//
//    let social_already_in_use: AppMessage = .error(
//        identifer: .string("SOCIAL_ALREADY_IN_USE"),
//        message: R.string.localizable.am_social_already_in_use()
//    )
//
//    let profile_not_filled: AppMessage = .error(
//        identifer: .string("PROFILE_NOT_FILLED"),
//        message: R.string.localizable.am_profile_not_filled()
//    )
//
//    let phone_is_used: AppMessage = .error(
//        identifer: .string("PHONE_IS_USED"),
//        message: R.string.localizable.am_phone_is_used()
//    )
//
//    let email_is_used: AppMessage = .error(
//        identifer: .string("EMAIL_IS_USED"),
//        message: R.string.localizable.am_email_is_used()
//    )
//
//    let validation_error: AppMessage = .error(
//        identifer: .string("VALIDATION_ERROR"),
//        message: R.string.localizable.am_validation_error()
//    )
//
//    let empty_required_fields: AppMessage = .error(
//        identifer: .string("EMPTY_REQUIRED_FIELDS"),
//        message: R.string.localizable.am_empty_required_fields()
//    )
//
//    let unsuported_file_format: AppMessage = .error(
//        identifer: .string("UNSUPPORTED_FILE_FORMAT"),
//        message: R.string.localizable.am_unsuported_file_format()
//    )
//
//    let already_registered_with_other_role: AppMessage = .error(
//        identifer: .string("ALREADY_REGISTERED_WITH_OTHER_ROLE"),
//        message: R.string.localizable.am_already_registered_with_other_role()
//    )
//
//    let deleting_reg_social: AppMessage = .error(
//        identifer: .string("DELETING_REG_SOCIAL"),
//        message: R.string.localizable.am_deleting_reg_social()
//    )
//
//    let invalid_coords: AppMessage = .error(
//        identifer: .string("INVALID_COORDS"),
//        message: R.string.localizable.am_invalid_coords()
//    )
//
//    let invalid_date_range: AppMessage = .error(
//        identifer: .string("INVALID_DATE_RANGE"),
//        message: R.string.localizable.am_invalid_date_range()
//    )
//
//    let username_wrong: AppMessage = .error(
//        identifer: .string("USERNAME_WRONG"),
//        message: R.string.localizable.am_username_wrong()
//    )
//
//    let username_taken: AppMessage = .error(
//        identifer: .string("USERNAME_TAKEN"),
//        message: R.string.localizable.am_username_taken()
//    )
//
//    let username_invalid_symbols: AppMessage = .error(
//        identifer: .string("USERNAME_INVALID_SYMBOLS"),
//        message: R.string.localizable.am_username_invalid_symbols()
//    )
//
//    let username_invalid_length: AppMessage = .error(
//        identifer: .string("USERNAME_INVALID_LENGTH"),
//        message: R.string.localizable.am_username_invalid_length()
//    )
//
//    let wrong_password: AppMessage = .error(
//        identifer: .string("WRONG_PASSWORD"),
//        message: R.string.localizable.am_wrong_password()
//    )
//
//    #warning("localized")
//    let appeal_exists: AppMessage = .error(
//        identifer: .string("APPEAL_EXISTS"),
//        message: "Вы уже откликнулись на эту смену"
//    )
//
//    #warning("localized")
//    let appels_limit_reached: AppMessage = .error(
//        identifer: .string("APPEALS_LIMIT_REACHED"),
//        message: "Слишком много откликов на смены с пересекающимся временем"
//    )
//
//    #warning("localized")
//    let shift_without_time: AppMessage = .error(
//        identifer: .string("SHIFT_WITHOUT_TIME"),
//        message: "У cмены нет времени начала и окончания"
//    )
//
//}
